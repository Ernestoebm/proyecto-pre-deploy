import Navbar from "../../components/Navbar2/navbar2";
import Car from "../../components/carousel/Car.jsx";
import Footer from "../../components/Footer/footer.jsx";

const ini2 = () => {
  return (
    <div>
        <Navbar />
        <Car />
        <Footer />
    </div>
  );
};

export default ini2;
